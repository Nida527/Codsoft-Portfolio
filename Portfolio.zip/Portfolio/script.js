
var typed = new Typed(".multiple-text" , {
    strings: ["Mobile App Developer" , "Coder" , "Frontend Developer" , "Backend Developer"],
    typeSpeed: 100, //typeSpeed type speed in milliseconds
    backSpeed: 100, //backSpeed backspacing speed in milliseconds
    backDelay: 1000, //backDelay time before backspacing in milliseconds
    loop: true
});

// Links used in this website
// 1- https://github.com/mattboldt/typed.js/ (For typing animation)
// 2- https://boxicons.com (For icons)
// 3- https://www.vecteezy.com/free-png/person (For images)